---
name: Imported artifact manifests
description: Re-registering imported Replit artifacts without losing project workflow identity
---

When importing a prebuilt bundle into a registered Replit artifact, copy the application source but keep the artifact manifest created for the current project. Bundles can carry stale artifact IDs, package names, and workflow commands; copying that metadata can deregister the new artifact and point workflows at the old package.

**Why:** The imported RACC bundle contained a frontend manifest for a different package identity, and copying it replaced the newly registered app's manifest until the artifact was recreated.

**How to apply:** Before copying an archive into an existing artifact, exclude `.replit-artifact/artifact.toml` and reconcile the package name with the registered slug. Update deployment settings through artifact manifest validation rather than editing the manifest in place.