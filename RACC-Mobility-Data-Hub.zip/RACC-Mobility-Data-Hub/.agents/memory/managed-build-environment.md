---
name: Managed build environment
description: Environment assumptions that artifact workflows inject into manual validation commands
---

Manual Vite builds for managed web artifacts need the same required `PORT` and `BASE_PATH` environment values that the artifact workflow injects automatically.

**Why:** A direct package build without `PORT` failed even though the managed preview workflow was healthy; repeating the workflow environment made the validation succeed.

**How to apply:** When validating an artifact outside its workflow, provide the artifact's configured port and base path explicitly rather than treating a bare package build as equivalent.