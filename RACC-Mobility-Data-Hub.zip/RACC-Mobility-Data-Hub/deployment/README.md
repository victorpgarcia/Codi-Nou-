# RACC Mobility Data Hub — portable deployment

This bundle contains the RACC Mobility dashboard, its FastAPI backend, and the
combined Aforament data. It is designed to run as one standard Docker web
service on Render, Railway, Fly.io, Google Cloud Run, Azure Container Apps, AWS
App Runner, or a private server. It does not require Replit.

## Fastest option: Docker

From the extracted bundle root:

```bash
docker build -f deployment/Dockerfile -t racc-mobility .
docker run --rm -p 8080:8080 \
  -e SESSION_SECRET="replace-with-a-long-random-value" \
  racc-mobility
```

Open `http://localhost:8080`.

The container listens on the `PORT` environment variable. Deployers that
provide `PORT` automatically can use the Dockerfile without changing it.
Set `SESSION_SECRET` to a long random value in the deployer's secret settings.

## Docker Compose

```bash
cp deployment/.env.example .env
# Edit .env and set SESSION_SECRET.
docker compose -f deployment/docker-compose.yml up --build
```

Open `http://localhost:8080`.

## Local development without Docker

Requirements:

- Node.js 20 or newer
- pnpm 9 or newer
- Python 3.11 or newer

Install dependencies and build the browser app:

```bash
pnpm install
PORT=4173 BASE_PATH=/ pnpm --filter @workspace/racc-mobility run build
python3 -m pip install -r artifacts/api-server/requirements.txt
```

Start the combined production server:

```bash
PORT=8080 SESSION_SECRET="replace-with-a-long-random-value" \
  python3 -m uvicorn deployment.app:app --host 0.0.0.0 --port 8080
```

## Health check

The API health endpoint is:

```text
/api/healthz
```

It returns `{"status":"ok"}` when the service is running.

## Included data

The Aforament tab reads the combined 551 road/PK/IMD records from the RACC and
Ministeri 2024 sources. The normalized data used by the API is included at:

```text
artifacts/api-server/aforaments_chart.json
```

## Notes for managed deployers

- Use the repository/bundle root as the Docker build context.
- Use `deployment/Dockerfile` as the Dockerfile path.
- Publish the deployer's assigned `PORT`.
- Add `SESSION_SECRET` as a secret environment variable.
- `DATABASE_URL` defaults to SQLite for a simple standalone deployment. Set it
  to a managed PostgreSQL connection string if persistent multi-instance data
  is required.

## Downloadable bundle contents

The portable ZIP contains only the source, lockfile, deployment files, data
assets, and documentation needed to build and run the service. It excludes
Replit workflows, generated `node_modules`, development caches, and local
databases.